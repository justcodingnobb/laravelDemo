<?php if(App::make('com')->ifCan('wxlinkage-add')): ?>
<?php $__env->startSection('rmenu'); ?>
	<a href="<?php echo e(url('/admin/wxlinkage/add',$pid)); ?>" class="btn-green f-l">[ 添加关联 ]</a>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

<table class="pure-table">
	<thead>
		<tr>
			<td width="60">排序</td>
			<td width="60">ID</td>
			<td>菜单名称</td>
			<td>值</td>
			<td>操作</td>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($l->listorder); ?></td>
			<td><?php echo e($l->id); ?></td>
			<td><a href="<?php echo e(url('/admin/wxlinkage/index',$l->id)); ?>"><?php echo e($l->name); ?></a>
				<?php if(App::make('com')->ifCan('wxlinkage-add')): ?>
				<a href="<?php echo e(url('/admin/wxlinkage/add',$l->id)); ?>" class="fa fa-plus-square add_submenu"></a>
				<?php endif; ?>
			</td>
			<td><?php echo e($l->val); ?></td>
			<td>
				<?php if(App::make('com')->ifCan('wxlinkage-edit')): ?>
				<a href="<?php echo e(url('/admin/wxlinkage/edit',$l->id)); ?>">修改</a> | 
				<?php endif; ?>
				<?php if(App::make('com')->ifCan('wxlinkage-del')): ?>
				<a href="<?php echo e(url('/admin/wxlinkage/del',$l->id)); ?>" class="confirm">删除</a>
				<?php endif; ?>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>