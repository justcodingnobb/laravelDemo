<?php if(App::make('com')->ifCan('menu-add')): ?>
<?php $__env->startSection('rmenu'); ?>
	<a href="<?php echo e(url('/admin/menu/add')); ?>" class="btn btn-info">添加菜单</a>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

<table class="table table-striped table-hover">
	<thead>
		<tr class="success">
			<td width="60">排序</td>
			<td width="60">ID</td>
			<td>菜单名称</td>
			<td>url</td>
			<td>显示</td>
			<td>操作</td>
		</tr>
	</thead>
	<tbody>
	<?php echo $treeHtml; ?>

	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>