<?php if(App::make('com')->ifCan('database-import')): ?>
<?php $__env->startSection('rmenu'); ?>
<a href="<?php echo e(url('/admin/database/import')); ?>" class="btn btn-info">数据库恢复</a>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<form action="" method="post">
	<?php echo e(csrf_field()); ?>

	<table class="table table-striped table-hover">
		<thead>
			<tr class="success">
				<th width='50'>
					<input type="checkbox" class="checkall"></th>
				<th width="150">名称</th>
				<th width="120">类型</th>
				<th width="180">编码</th>
				<th>大小</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $alltables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<tr>
				<td>
					<input type="checkbox" name="tables[]" class="check_s" value="<?php echo e($a->Name); ?>"></td>
				<td><?php echo e($a->Name); ?></td>
				<td><?php echo e($a->Engine); ?></td>
				<td><?php echo e($a->Collation); ?></td>
				<td><?php echo e(($a->Data_length + $a->Index_length)/1048576); ?> MB</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</tbody>
	</table>
	<div class="btn-group" data-toggle="buttons">
		<label class="btn btn-primary">
			<input type="checkbox" autocomplete="off" class="checkall">全选</label>
		<button class="btn btn-danger">备份</button>
	</div>
</form>
<script>
	$(".checkall").bind('change',function(){
		if($(this).is(":checked"))
		{
			$(".check_s").each(function(s){
				$(".check_s").eq(s).prop("checked",true);
			});
		}
		else
		{
			$(".check_s").each(function(s){
				$(".check_s").eq(s).prop("checked",false);
			});
		}
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>