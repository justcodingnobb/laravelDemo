<?php $__env->startSection('content'); ?>

<div class="priv-tree">
	<form action="" class="" method="post">
	<?php echo e(csrf_field()); ?>

	<?php echo $treePriv; ?>


	<button type="submit" name="dosubmit" class="btn btn-info mt10 clearfix">提交</button>
	</form>
</div>

<script>
	$(function(){
		$(".check-mr").bind('change',function(){
			if($(this).is(":checked"))
			{
				$(this).prop('checked',true);
				$(this).parent('.checkbox-inline').parent('li').children('ul').find('.check-mr').prop('checked',true);
			}
			else
			{
				$(this).prop("checked",false);
				$(this).parent('.checkbox-inline').parent('li').children('ul').find('.check-mr').prop("checked",false);
			}
		});
		var urlArr = [<?php echo $rids; ?>];
		$(".check-mr").each(function(s){
			var thisVal = $(this).val();
			$.each(urlArr,function(i){
				if(urlArr[i] == thisVal){
					$(".check-mr").eq(s).prop("checked",true);
				}
			});
		});
	});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>