<?php $__env->startSection('rmenu'); ?>
	<?php if(App::make('com')->ifCan('wxmenu-add')): ?><a href="<?php echo e(url('/admin/wxmenu/add',$pid)); ?>" class="btn-green f-l">[ 添加菜单 ]</a><?php endif; ?>
	<?php if(App::make('com')->ifCan('wxmenu-update')): ?><a href="<?php echo e(url('/admin/wxmenu/update')); ?>" class="btn-green f-l">[ 刷新菜单 ]</a><?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<table class="pure-table">
	<thead>
		<tr>
			<td width="60">排序</td>
			<td width="60">ID</td>
			<td>菜单名称</td>
			<td>类型</td>
			<td>值</td>
			<td>操作</td>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($l->listorder); ?></td>
			<td><?php echo e($l->id); ?></td>
			<td><a href="<?php echo e(url('/admin/wxmenu/index',$l->id)); ?>"><?php echo e($l->name); ?></a>
				<?php if(App::make('com')->ifCan('wxmenu-add')): ?>
				<a href="<?php echo e(url('/admin/wxmenu/add',$l->id)); ?>" class="fa fa-plus-square add_submenu"></a>
				<?php endif; ?>
			</td>
			<td><?php echo e($linkname[$l->type]); ?></td>
			<td><?php echo e($l->key); ?><?php echo e($l->url); ?></td>
			<td>
				<?php if(App::make('com')->ifCan('wxmenu-edit')): ?>
				<a href="<?php echo e(url('/admin/wxmenu/edit',$l->id)); ?>">修改</a> | 
				<?php endif; ?>
				<?php if(App::make('com')->ifCan('wxmenu-del')): ?>
				<a href="<?php echo e(url('/admin/wxmenu/del',$l->id)); ?>" class="confirm">删除</a>
				<?php endif; ?>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>