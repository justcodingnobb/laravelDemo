<?php $__env->startSection('rmenu'); ?>
    <?php if(App::make('com')->ifCan('wx-emptycache')): ?><a href="<?php echo e(url('/admin/wx/emptycache')); ?>" class="btn-green f-l">[ 清空缓存 ]</a><?php endif; ?>
    <?php if(App::make('com')->ifCan('wx-emptydata')): ?><a href="<?php echo e(url('/admin/wx/emptydata')); ?>" class="btn-green f-l">[ 清空数据 ]</a><?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="" class="pure-form pure-form-stacked" method="post">
	<?php echo e(csrf_field()); ?>

	<label for="appid">APPID：</label>
	<input type="text" name="data[appid]" class="pure-input-1-4" value="<?php echo e($info->appid); ?>">
	<?php if($errors->has('data.appid')): ?>
        <span class="help-block">
        	<?php echo e($errors->first('data.appid')); ?>

        </span>
    <?php endif; ?>
	<label for="appsecret">appsecret：</label>
	<input type="text" name="data[appsecret]" value="<?php echo e($info->appsecret); ?>" class="pure-input-1-4">
	<?php if($errors->has('data.appsecret')): ?>
        <span class="help-block">
        	<?php echo e($errors->first('data.appsecret')); ?>

        </span>
    <?php endif; ?>
    <label for="rzurl">认证网址：</label>
	<input type="text" name="data[rzurl]" value="<?php echo e($info->rzurl); ?>" class="pure-input-1-4">
	<?php if($errors->has('data.rzurl')): ?>
        <span class="help-block">
        	<?php echo e($errors->first('data.rzurl')); ?>

        </span>
    <?php endif; ?>
	<label for="token">Token：可以是字母、数字、下划线、破折号</label>
	<input type="text" name="data[token]" value="<?php echo e($info->token); ?>" class="pure-input-1-4">
	<?php if($errors->has('data.token')): ?>
        <span class="help-block">
        	<?php echo e($errors->first('data.token')); ?>

        </span>
    <?php endif; ?>
	<br />
	<button type="submit" name="dosubmit" class="pure-button pure-button-primary pure-u-1-12 mr10">提交</button> <button type="reset" name="reset" class="pure-button pure-u-1-12">重填</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>