<?php $__env->startSection('rmenu'); ?>
	<?php if(App::make('com')->ifCan('type-add')): ?>
	<a href="<?php echo e(url('/admin/type/add/0')); ?>" class="btn btn-info">添加分类</a>
	<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<table class="table table-striped table-hover">
	<thead>
		<tr class="success">
			<td width="60">排序</td>
			<td width="60">ID</td>
			<td>分类名称</td>
			<td>操作</td>
		</tr>
	</thead>
	<tbody>
	<?php echo $treeHtml; ?>

	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>