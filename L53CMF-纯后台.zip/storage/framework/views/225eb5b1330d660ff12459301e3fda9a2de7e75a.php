<?php $__env->startSection('content'); ?>

	<?php if(App::make('com')->ifCan('index-main')): ?>
	<?php echo e($main); ?>

	<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>