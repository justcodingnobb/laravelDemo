<?php if(App::make('com')->ifCan('section-add')): ?>
<?php $__env->startSection('rmenu'); ?>
	<a href="<?php echo e(url('/admin/section/add')); ?>" class="btn btn-info">添加部门</a>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<table class="table table-striped table-hover">
	<thead>
		<tr class="success">
			<th width="50">ID</th>
			<th>部门名称</th>
			<th>状态</th>
			<th>操作</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($m->id); ?></td>
			<td><?php echo e($m->name); ?></td>
			<td>
				<?php if($m->status == 1): ?>
				<span class="color-green">正常</span>
				<?php else: ?>
				<span class="color-red">禁用</span>
				<?php endif; ?>
			</td>
			<td>
				<?php if(App::make('com')->ifCan('section-edit')): ?>
				<a href="<?php echo e(url('/admin/section/edit',$m->id)); ?>" class="btn btn-sm btn-info">修改</a>
				<?php endif; ?>
				<?php if(App::make('com')->ifCan('section-del')): ?>
				<a href="<?php echo e(url('/admin/section/del',$m->id)); ?>" class="confirm btn btn-sm btn-danger">删除</a>
				<?php endif; ?>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>
<!-- 分页，appends是给分页添加参数 -->
<div class="pages clearfix">
<?php echo $list->links(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>