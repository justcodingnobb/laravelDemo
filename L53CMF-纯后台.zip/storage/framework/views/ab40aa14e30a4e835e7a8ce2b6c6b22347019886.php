<?php $__currentLoopData = $leftmenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lm): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	<h3 class="left_h3"><span class="glyphicon glyphicon-align-left" aria-hidden="true"></span><?php echo e($lm['name']); ?></h3>
	<ul class="left_list">
		<?php $__currentLoopData = $lm['submenu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slm): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<li class="sub_menu clearfix" id="left_menu<?php echo e($slm['id']); ?>"><span class="glyphicon glyphicon-leaf" aria-hidden="true"></span><a href="javascript:_LM(<?php echo e($slm['id']); ?>,'/admin/<?php echo e($slm['url']); ?>')" class="sub_menu_a"><?php echo e($slm['name']); ?></a></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
