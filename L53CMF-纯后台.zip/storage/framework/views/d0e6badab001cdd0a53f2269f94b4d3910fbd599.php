<?php if(App::make('com')->ifCan('log-del')): ?>
<?php $__env->startSection('rmenu'); ?>
	<a href="<?php echo e(url('/admin/log/del')); ?>" class="btn btn-info">清除七天前日志</a>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<!-- 按用户查看 -->
<div class="clearfix">
	<form action="" method="get" class="form-inline">
		<div class="form-group">
			<select name="admin_id" id="admin_id" class="form-control">
				<option value="">请选择</option>
				<?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<option value="<?php echo e($a->id); ?>"><?php echo e($a->name); ?> - <?php echo e($a->realname); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</select>
			<button class="btn btn-sm btn-info">查找</button>
		</div>
	</form>
</div>

<table class="table table-striped table-hover mt10">
	<thead>
		<tr class="success">
			<th width="50">ID</th>
			<th width="120">用户</th>
			<th>url</th>
			<th width="180">插入时间</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($a->id); ?></td>
			<td><?php echo e($a->user); ?></td>
			<td><?php echo e($a->url); ?></td>
			<td><?php echo e($a->created_at); ?></td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>
<!-- 分页，appends是给分页添加参数 -->
<div class="pages clearfix">
<?php echo $list->links(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>