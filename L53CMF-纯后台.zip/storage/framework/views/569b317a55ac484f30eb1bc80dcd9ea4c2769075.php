<?php $__env->startSection('content'); ?>
<form action="" class="pure-form pure-form-stacked" method="post">
	<?php echo e(csrf_field()); ?>

    <div class="form-group">
    <label for="name">用户名：<?php echo e($info->name); ?></label>
    </div>

    <div class="row">
        <div class="col-xs-4">
            <div class="form-group">
            <label for="name">新密码：<span class="color-red">*</span></label>
            <input type="password" name="data[password]" class="form-control" value="<?php echo e(old('data.password')); ?>">
            <?php if($errors->has('data.password')): ?>
                <span class="help-block">
                    <?php echo e($errors->first('data.password')); ?>

                </span>
            <?php endif; ?>
            </div>
            <div class="form-group">
            <label for="name">确认密码：<span class="color-red">*</span></label>
        	<input type="password" name="data[password_confirmation]" class="form-control" value="<?php echo e(old('data.password_confirmation')); ?>">
            <?php if($errors->has('data.password_confirmation')): ?>
                <span class="help-block">
                    <?php echo e($errors->first('data.password_confirmation')); ?>

                </span>
            <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="btn-group mt10">
        <button type="reset" name="reset" class="btn btn-warning">重填</button>
        <button type="submit" name="dosubmit" class="btn btn-info">提交</button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>