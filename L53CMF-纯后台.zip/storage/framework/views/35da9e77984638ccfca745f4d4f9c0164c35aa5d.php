<?php if(App::make('com')->ifCan('role-add')): ?>
<?php $__env->startSection('rmenu'); ?>
	<a href="<?php echo e(url('/admin/role/add')); ?>" class="btn btn-info">添加角色</a>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<table class="table table-striped table-hover">
	<thead>
		<tr class="success">
			<th width="50">ID</th>
			<th>角色名</th>
			<th>状态</th>
			<th>操作</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($m->id); ?></td>
			<td><?php echo e($m->name); ?></td>
			<td>
				<?php if($m->status == 1): ?>
				<span class="color-green">正常</span>
				<?php else: ?>
				<span class="color-red">禁用</span>
				<?php endif; ?>
			</td>
			<td>
				<!-- 超管有所有权限 -->
				<?php if((session('user')->id == 1 || App::make('com')->ifCan('role-priv')) && $m->id != 1): ?>
				<a href="<?php echo e(url('/admin/role/priv',$m->id)); ?>" class="btn btn-sm btn-info">权限管理</a>
				<?php endif; ?>
				<!-- <?php if(App::make('com')->ifCan('role-catepriv') && $m->id != 1): ?>
				<a href="<?php echo e(url('/admin/role/catepriv',$m->id)); ?>" class="btn btn-sm btn-info">栏目权限</a>
				<?php endif; ?> -->
				<?php if(App::make('com')->ifCan('role-edit')): ?>
				<a href="<?php echo e(url('/admin/role/edit',$m->id)); ?>" class="btn btn-sm btn-info">修改</a>
				<?php endif; ?>
				<?php if(App::make('com')->ifCan('role-del') && $m->id != 1): ?>
				<a href="<?php echo e(url('/admin/role/del',$m->id)); ?>" class="confirm btn btn-sm btn-danger">删除</a>
				<?php endif; ?>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>
<!-- 分页，appends是给分页添加参数 -->
<div class="pages clearfix">
<?php echo $list->links(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>