<?php if(App::make('com')->ifCan('wxmsg-add')): ?>
<?php $__env->startSection('rmenu'); ?>
	<a href="<?php echo e(url('/admin/wxmsg/add')); ?>" class="btn-green f-l">[ 添加回复 ]</a>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

<table class="pure-table">
	<thead>
		<tr>
			<th width="50">ID</th>
			<th width="120">回复类型</th>
			<th>关键字</th>
			<th>回复标题</th>
			<th width="150">操作</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($a->id); ?></td>
			<td><?php echo e($type[$a->type]); ?></td>
			<td><?php echo e($a->con); ?></td>
			<td><?php echo e($a->title); ?></td>
			<td>
				<?php if(App::make('com')->ifCan('wxmsg-edit')): ?>
				<a href="<?php echo e(url('/admin/wxmsg/edit',$a->id)); ?>">修改</a> | 
				<?php endif; ?>
				<?php if(App::make('com')->ifCan('wxmsg-del')): ?>
				<a href="<?php echo e(url('/admin/wxmsg/del',$a->id)); ?>" class="confirm">删除</a>
				<?php endif; ?>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>
<!-- 分页，appends是给分页添加参数 -->
<div class="pages clearfix">
<?php echo $list->links(); ?>

<span class="f-r">共 <?php echo $list->count(); ?> 页</span>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>