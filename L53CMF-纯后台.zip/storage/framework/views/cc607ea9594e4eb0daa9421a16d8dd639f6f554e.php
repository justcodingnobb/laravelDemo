<?php $__env->startSection('content'); ?>
<form action="" class="pure-form pure-form-stacked" method="post">
	<?php echo e(csrf_field()); ?>


	<div class="row">
        <div class="col-xs-4">
			<div class="form-group">
				<label for="name">
					角色名称：
					<span class="color-red">*</span>
				</label>
				<input type="text" name="data[name]" class="form-control" value="<?php echo e(old('data.name')); ?>">
				<?php if($errors->has('data.name')): ?>
				<span class="help-block"><?php echo e($errors->first('data.name')); ?></span>
				<?php endif; ?>
			</div>
			<div class="form-group">
				<label for="status">状态：</label>
				<label class="radio-inline"><input type="radio" name="data[status]" checked="checked" class="input-radio" value="1">
					启用</label>
					<label class="radio-inline"><input type="radio" name="data[status]" class="input-radio" value="0">禁用</label>
			</div>
		</div>
	</div>
	<div class="btn-group mt10">
		<button type="reset" name="reset" class="btn btn-warning">重填</button>
		<button type="submit" name="dosubmit" class="btn btn-info">提交</button>
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>