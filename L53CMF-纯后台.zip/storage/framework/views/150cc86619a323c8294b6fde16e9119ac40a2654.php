<?php $__env->startSection('content'); ?>
<form action="" class="pure-form pure-form-stacked" method="post">
    <?php echo e(csrf_field()); ?>

    <!-- 提交返回用的url参数 -->
    <input type="hidden" name="ref" value="<?php echo $ref; ?>">
    <div class="row">
        <div class="col-xs-4">

            <div class="form-group">
                <label for="name">用户名：<?php echo e($info->name); ?></label>
            </div>
            <div class="form-group">
                <label for="section_id">
                    部门：
                    <span class="color-red">*</span>
                </label>
                <select name="data[section_id]" id="data[section_id]" class="form-control">
                    <option value="">请选择</option>
                    <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <option value="<?php echo e($r->
                        id); ?>"<?php if($r->id == $info->section_id): ?> selected="selected"<?php endif; ?>><?php echo e($r->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </select>
                <?php if($errors->has('data.section_id')): ?>
                <span class="help-block"><?php echo e($errors->first('data.section_id')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="role_id">
                    角色：
                    <span class="color-red">*</span>
                </label>
                <?php $__currentLoopData = $rolelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <label class="checkbox-inline"><input type="checkbox" name="role_id[]" value="<?php echo e($r->
                    id); ?>" class="check-mr"> <?php echo e($r->name); ?></label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </div>
            <div class="form-group">
                <label for="name">
                    真实姓名：
                    <span class="color-red">*</span>
                </label>
                <input type="text" name="data[realname]" class="form-control" value="<?php echo e($info->
                realname); ?>">
            <?php if($errors->has('data.realname')): ?>
                <span class="help-block"><?php echo e($errors->first('data.realname')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="name">
                    邮箱：
                    <span class="color-red">*</span>
                </label>
                <input type="text" name="data[email]" class="form-control" value="<?php echo e($info->
                email); ?>">
            <?php if($errors->has('data.email')): ?>
                <span class="help-block"><?php echo e($errors->first('data.email')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="name">
                    电话：
                    <span class="color-red">*</span>
                </label>
                <input type="text" name="data[phone]" class="form-control" value="<?php echo e($info->
                phone); ?>">
            <?php if($errors->has('data.phone')): ?>
                <span class="help-block"><?php echo e($errors->first('data.phone')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <!-- 初始用户不能被禁用及删除 -->
                <?php if($info['id'] != 1): ?>
                <label for="name">状态：</label>
                <?php if($info['status'] == 1): ?>
                <input type="radio" name="data[status]" checked="checked" class="input-radio" value="1">
                启用
                <input type="radio" name="data[status]" class="input-radio" value="0">
                禁用
            <?php else: ?>
                <input type="radio" name="data[status]" class="input-radio" value="1">
                启用
                <input type="radio" name="data[status]" checked="checked" class="input-radio" value="0">
                禁用
            <?php endif; ?>
            <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="btn-group mt10">
        <button type="reset" name="reset" class="btn btn-warning">重填</button>
        <button type="submit" name="dosubmit" class="btn btn-info">提交</button>
    </div>
</form>

<script>
    $(function(){
        var rids = [<?php echo $rids; ?>];
        $(".check-mr").each(function(s){
            var thisVal = $(this).val();
            $.each(rids,function(i){
                if(rids[i] == thisVal){
                    $(".check-mr").eq(s).prop("checked",true);
                }
            });
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>